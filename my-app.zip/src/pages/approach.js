import React from "react";

const Approach = () => {
  return (
    <div className='page'>
      <div className='container'>
        <div className='row'>
          <h3>This is the approach page</h3>
        </div>
      </div>
    </div>
  );
};

export default Approach;
