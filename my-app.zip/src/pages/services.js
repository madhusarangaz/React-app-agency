import React from "react";

const Services = () => {
  return (
    <div className='page'>
      <div className='container'>
        <div className='row'>
          <h3>This is the services page</h3>
        </div>
      </div>
    </div>
  );
};

export default Services;
